
package AudioVibe;

import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.*;  
import java.util.Scanner;


public class End_user extends users
{
   public String name;//****
    public String gender;//****
    //public String phoneNumber;
   // public String username;//****
    public int Nationality;//****
    public String DOB;//****
    public String POB;//****
    public String address;//****
    //public int QA_ID;//****
    static Scanner in = new Scanner(System.in);
    
    @Override
    public void welcome()
    {
        System.out.println("\n\t\tEmbark on a culinary adventure with tales from kitchens around the world on The Global Flavor Chronicles.");
    }
    
    public String getRusername() {
        return name;
    }

    public void setRusername() {
        String adminname=in.next();
        this.name = adminname;
    }
    
    public String getaddress() {
        return address;
    }

    public void setaddress() {
        String address2=in.next();
        this.address = address2;
    }
    public String getdob() {
        return DOB;
    }

    public void setdob() {
        String dob=in.next();
        this.DOB = dob;
    }
    public String getpob() {
        return POB;
    }

    public void setpob() {
        String pob=in.next();
        this.POB = pob;
    }
    public String getgender() {
        return gender;
    }

    public void setgender() {
        String gen=in.next();
        this.gender = gen;
    }
    public int getnat() {
        return Nationality;
    }

    public void setnat() {
        int nationality=in.nextInt();
        this.Nationality = nationality;
    }
    public void UpdateInfo(End_user so)
   {
        System.out.print("\nEnter the full Name\n");
        so.setRusername();
        System.out.print("\nEnter the Email\n");
        so.setEmail();
        System.out.print("\nEnter the Phone\n");
        so.setPhone();
        System.out.print("\nEnter the address\n");
        so.setaddress();
        System.out.print("\nEnter the Date Of Birth\n");
        so.setdob();
        System.out.print("\nEnter the Place Of Birth\n");
        so.setpob();
        System.out.print("\nEnter the Gender \n M for male \n F for female\n");
        so.setgender();
        System.out.print("\nChoose on of  the Nationality enter the no \n");
        so.viewdbnat();
        so.setnat();
        
       try
       { 
           
            if (this.userValid())
            {
                
                Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection
                    ("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
                Statement stmt=con.createStatement(); 
         
          
                String insert_user = "UPDATE users SET  phone = \'" 
                    + so.phone + "\', Email =\'" + so.email + "\'  WHERE Username = \'" + so.username +"\'";
           
                stmt.executeUpdate(insert_user);
                
                insert_user = "UPDATE end_user SET  name = \'" 
                    + so.name + "\', address =\'" + so.address + "\', DOB =\'" 
                        + so.DOB + "\', POB =\'"  + so.POB + "\', Gender =\'" 
                        + so.gender + "\', Nat_id =" + so.Nationality + " WHERE User_id = \'" + so.User_id +"\'";
           
                stmt.executeUpdate(insert_user);
                System.out.println("Password Changed  successfully ");
                con.close(); 
           }   
           else
           {
               System.out.println("You have not Permission to Change the Password");
           }
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
       
       
  
   }
    
    public void userMenu(users us)
    {
        
        
            int ch;
            do
            {
                System.out.print("\n1_My Account"
                    + "\n2_My Podcast List"
                    + "\n4_Back"
                    + "\n-->");
                ch = in.nextInt();
                switch(ch)
                {
                    case 2:
                        myPodcastList(us.User_id);
                        break;
                    case 1:
                        System.out.print("User_id: " +  us.User_id);
                        myAccount(us.User_id);
                        break;
                    default:
                        System.out.println("Invalid");
                }
            }while(ch!=4);
        
    }
    
    public End_user myAccount(int uid)
    {  
        End_user user= new End_user();
       try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
           ResultSet rs=stmt.executeQuery("select Username, phone, Email, regdate from  users WHERE User_id = " + uid );
         while(rs.next()) 
         {
           user.username = rs.getString(1);
           user.phone = rs.getString(2);
           user.email = rs.getString(3);
           user.reg_date = rs.getString(4);
         }
         rs=stmt.executeQuery("select name, address, DOB, POB, gender, Nat_id from end_user WHERE user_id = " + uid );
         while(rs.next()) 
         {
           user.name = rs.getString(1);
           user.address = rs.getString(2);
           user.DOB = rs.getString(3);
          user.POB = rs.getString(4);
           user.gender = rs.getString(5);
           user.Nationality = rs.getInt(6);
           System.out.println("");
         }
         con.close();  
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              } 
       return user;
    }
    
    
    public void myPodcastList(int uid)
    {
        int ch;
        System.out.print("\n User ID : " + uid);
        PlayList Pl = new PlayList();
            do
            {
                System.out.print("\n1_Add Play List"
                    + "\n2_Update Play List"
                    + "\n3_Delete Play List"
                    + "\n4_Dispaly all my Play List"
                    + "\n5_ Manage Play List"
                    + "\n6_Back"
                    +"\n-->");
                ch = in.nextInt();
                switch(ch)
                {
                    case 1:
                        Pl.setPlayListName();
                        Pl.setcatid();
                        Pl.setuser_id(uid);
                        Pl.setnotdeleted();
                        Pl.setCreationDate();
                        Pl.setPlayListID(uid);
                        Pl.addtodbPL(Pl);
                        break;
                    case 2:
                        Pl.DisplayPlayList(uid);
                        System.out.print("\nEnter the Id for Play list to Update : ");
                        Pl.PlayListID = in.nextInt();
                        Pl.setPlayListName();
                        Pl.setcatid();
                        Pl.user_id = uid;
                        Pl.updatedbPL(Pl);
                       
                       /// myPodcastList(us.User_id);
                        break;
                    case 3:
                        Pl.DisplayPlayList(uid);
                        System.out.print("\nEnter the Id for Play list to Delete : ");
                        int plid = in.nextInt();
                        Pl.DeletedbPL(uid, plid  );
                        
                        break;
                    case 4:
                        Pl.DisplayPlayList(uid);
                        break;
                    case 5:
                        Pl.DisplayPlayList(uid);
                        System.out.print("\nEnter the Id for Play list to Delete : ");
                        plid = in.nextInt();
                        this.ManagePlylist(uid, plid);
                        
                        break;
                    default:
                        System.out.println("Invalid");
                }
            }while(ch!=6);
        
    }
    
    public void ManagePlylist(int uid, int plid)
    {
        int ch, j;
        System.out.print("\n User ID : " + uid);
        PlayList Pl = new PlayList();
            do
            {
                System.out.print("\n1_Add to Play List"
                    + "\n2_Delete from Play List"
                    + "\n3_Make it Empty"
                    + "\n4_Back"
                    +"\n-->");
                ch = in.nextInt();
                switch(ch)
                {
                    case 1:
                        do{
                        Pl.AddtoPlylst( uid,  plid);
                        System.out.print("\n9 to finishing add");
                        j = in.nextInt();
                        }while ( j!=9);
                        break;
                    case 2:
                        Pl.DisplayPlayListSound(uid, plid);
                        System.out.print("\nEnter Sound id you want delete from PlayList");
                        j = in.nextInt();
                       Pl.DeleteSoundfromPL(uid, plid, j);
                        break;
                    case 3:
                        Pl.MakeitEmpty(uid, plid);
                        break;
                    
                    default:
                        System.out.println("Invalid");
                }
            }while(ch!=4);
        
    }
    
}
