package AudioVibe;

import java.util.Scanner;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.*;  
import javax.swing.JOptionPane;

public class users 
{
    
    int max=0;
    public String email;
    public String phone;
    public String username;
    public String password;
    public String reg_date;
    public int user_type;
    public int loginstatus;
    public int User_id;
    static Scanner in = new Scanner(System.in);
    
   public void welcome()
    {
        System.out.println("\n\t\tJoin us for a journey of curiosity as we unravel intriguing topics from every corner of the globe.");
    }
   public users() 
    {
        this.welcome();
    }
   
   public void adduser() throws ClassNotFoundException
   {
        End_user user = new End_user();
        System.out.print("\n******************************\n");
        user.max= user.getmax();
        System.out.print("\n******************************\n");
        System.out.print("\n User ID =\n" + user.max);
        System.out.print("\nEnter the full Name\n");
        user.setRusername();
        System.out.print("\nEnter the User Name\n");
        user.setUsername();
        System.out.print("\nEnter the Password\n");
        user.setPassword();
        System.out.print("\nEnter the Email\n");
        user.setEmail();
        System.out.print("\nEnter the Phone\n");
        user.setPhone();
        System.out.print("\nEnter the register date\n");
        user.setregdate();
        System.out.print("\nEnter the address\n");
        user.setaddress();
        System.out.print("\nEnter the Date Of Birth\n");
        user.setdob();
        System.out.print("\nEnter the Place Of Birth\n");
        user.setpob();
        System.out.print("\nEnter the Gender \n M for male \n F for female\n");
        user.setgender();
        System.out.print("\nChoose on of  the Nationality enter the no \n");
        user.viewdbnat();
        user.setnat();
        user.setuser();
        user.setlogout();
        user.addtodbusers();
        user.addtodbenduser(user.max,user.name, user.DOB, user.POB, user.address, user.gender, user.Nationality);
        System.out.print("\nUser added Successfully \n");
        RandomQAs Rqas = new RandomQAs();
        Rqas.setEpisodeNo();
        Rqas.setPodcastProgramNo();
        Rqas.setListenORwatch();
        Rqas.setChooseInterest();
        Rqas.setNonArabic();
        Rqas.setUser(user.max);
        addtodbQAs(Rqas);
   }
   
   public void adduser(String name, String fname, String pass, String email, String phone, String dob, String pob, String address, String gen, int nat,String reg, int uid) throws ClassNotFoundException
   {
        End_user user = new End_user();
        user.DOB = dob;
        user.Nationality = nat;
        user.POB = pob;
        user.User_id = uid;
        user.address = address;
        user.email = email;
        user.gender = gen;
        user.loginstatus = 0;
        user.name = fname;
        user.password = pass;
        user.phone = phone;
        user.reg_date = reg;
        user.user_type = 2;
        user.username = name;
        user.addtodbusers();
        user.addtodbenduser(user.User_id,user.name, user.DOB, user.POB, user.address, user.gender, user.Nationality);
        System.out.print("\nUser added Successfully \n");
       /* RandomQAs Rqas = new RandomQAs();
        Rqas.setEpisodeNo();
        Rqas.setPodcastProgramNo();
        Rqas.setListenORwatch();
        Rqas.setChooseInterest();
        Rqas.setNonArabic();
        Rqas.setUser(user.max);
        addtodbQAs(Rqas);*/
   }
   
   public void addtodbQAs(RandomQAs qas )
   {
       try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","Jj112233S");  
           Statement stmt=con.createStatement(); 
          
           String insert_user = "insert into randomqas (User_id, episodesno, podcastprogramno, chooseintrest, listenORwatch, nonArabic) values(" 
                   + qas.user_id + ",\"" +  qas.episodeNo + "\""+ ",\"" + qas.podcastProgramNo + "\""+ ",\"" + qas.chooseInterest + "\""+ ",\"" + qas.listenORwatch + "\""+ ",\"" + qas.nonArabic + "\")";
           stmt.executeUpdate(insert_user);
           System.out.println("Data inserted successfully in Users table");
           con.close();  
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
  
   }
   
    public void addtodbQAs(int userid , int episodeno, int podcastprogramno, String chooseinterest, String listenorwatch , String nonarabic)
   {
       try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","Jj112233");  
           Statement stmt=con.createStatement(); 
          
           String insert_user = "insert into randomqas (User_id, episodesno, podcastprogramno, chooseintrest, listenORwatch, nonArabic) values(" 
                   + userid + ",\"" +  episodeno + "\""+ ",\"" + podcastprogramno + "\""+ ",\"" + chooseinterest + "\""+ ",\"" + listenorwatch + "\""+ ",\"" + nonarabic + "\")";
           stmt.executeUpdate(insert_user);
           System.out.println("Data inserted successfully in Users table");
           con.close();  
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
  
   }
   
   public void addadmin() throws ClassNotFoundException
   {
        admin user = new admin();
        System.out.print("\n******************************\n");
        user.max= user.getmax();
        System.out.print("\n******************************\n");
        System.out.print("\nEnter the full Name\n");
        user.setadminname();
        System.out.print("\n User ID =\n" + user.max);
        System.out.print("\nEnter the User Name\n");
        user.setUsername();
        System.out.print("\nEnter the Password\n");
        user.setPassword();
        System.out.print("\nEnter the Email\n");
        user.setEmail();
        System.out.print("\nEnter the Phone\n");
        user.setPhone();
        System.out.print("\nEnter the register date\n");
        user.setregdate();
        user.setadmin();
        user.setlogout();
        user.addtodbusers();
        addtodbAdmin(user.max,user.admin_name);
        System.out.print("\n Admin added Successfully \n");
   }
   
   public void addadmin(String fullname, String username, String pass, String email, String phone, String rdate ) throws ClassNotFoundException
   {
        admin user = new admin();
        
        user.max= user.getmax();
        user.admin_name= fullname;
        user.email=email;
        user.loginstatus=0;
        user.password=pass;
        user.phone=phone;
        user.user_type=1;
        user.username=username;
        user.reg_date=rdate;
        user.addtodbusers();
        addtodbAdmin(user.max,user.admin_name);
        System.out.print("\n Admin added Successfully \n");
   }
   
   public void viewdbusers()
   {
       try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","Jj112233");  
           Statement stmt=con.createStatement(); 
           ResultSet rs=stmt.executeQuery("select * from users");
         while(rs.next())  
          System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)
                  +"  "+rs.getString(4)+"  "+rs.getString(5)+"  "+rs.getString(6)
          +"  "+rs.getString(7)+"  "+rs.getString(8));  
         con.close();  
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
  
   }
    public void viewdbnat()
   {
       try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","Jj112233");  
           Statement stmt=con.createStatement(); 
           ResultSet rs=stmt.executeQuery("select * from nationality");
         while(rs.next())  
          System.out.println(rs.getInt(1)+"  "+rs.getString(2));  
         con.close();  
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
  
   }
    
    public int getmax()
   {
       try
       { 
           int dbmax = 0;
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","Jj112233");  
           Statement stmt=con.createStatement(); 
           ResultSet rs=stmt.executeQuery("select MAX(User_id)+1 from users");
           
           while(rs.next())
           {
            // System.out.println(rs.getInt(1)); 
           dbmax=rs.getInt(1);
          
           }
           
         con.close();
         //this.max = dbmax;
         //System.out.println(dbmax);
         return dbmax;
        }
        catch(Exception e)
              { 
                  System.out.println(e);
                  return 0;
              }  
  
   }
    
   public void addtodbusers()
   {
       try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","Jj112233");  
           Statement stmt=con.createStatement(); 
           int max = getmax();
           String insert_user = "insert into users (User_id,Username, Password, regdate, phone, Email, loginstatus, user_type) values(" + max + ",\"" +  username + "\""+ ",\"" + password + "\""+ ",\"" + reg_date + "\""+ ",\"" + phone + "\""+ ",\"" + email + "\""+ "," + loginstatus + ""+ "," + user_type +  ")";
           stmt.executeUpdate(insert_user);
           System.out.println("Data inserted successfully in Users table");
           con.close();  
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
  
   }
   
   public void addtodbAdmin(int id , String name)
   {
       try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","Jj112233");  
           Statement stmt=con.createStatement(); 
          
           String insert_user = "insert into admin (Admin_id, Admin_name) values(" + id + ",\"" +  name + "\")" ;
           System.out.println(insert_user);
           stmt.executeUpdate(insert_user);
           System.out.println("Data inserted successfully in Admin table");
           con.close();  
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
  
   }
     
   public void addtodbenduser(int id, String name, String dob, String pob, String address2, String gen, int nat )
   {
       try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","Jj112233");  
           Statement stmt=con.createStatement(); 
           String insert_user = "insert into end_user (user_id, name, address, DOB, POB, Gender, Nat_id ) values(";
           insert_user = insert_user + id + ",\"" ;
           insert_user = insert_user +  name + "\",\"" + address2 + "\",\"";
           insert_user = insert_user + dob + "\",\"" + pob + "\",\"" + gen + "\"," + nat + ")";
           System.out.println(insert_user);
           stmt.executeUpdate(insert_user);
           System.out.println("Data inserted successfully in Admin table");
           con.close();  
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
  
   }
   
   
   
    public String getEmail() {
        return email;
    }

    public void setEmail() {
        String email2=in.next();
        this.email = email2;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone() {
        String phoneNumber=in.next();
        this.phone = phoneNumber;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername() {
        String user_name=in.next();
        this.username = user_name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword() {
        String password2=in.next();
        this.password = password2;
    }
    public String getregdate() {
        return reg_date;
    }

    public void setregdate() {
        String regdate= in.next();
        this.reg_date = regdate;
    }
    public int getuserid() {
        return User_id;
    }

    public void setuserid(int userid) {
        this.User_id = userid;
    }
    public int getusertype() {
        return user_type;
    }

    public void setadmin() {
        this.user_type = 1;
    }
    public void setuser() {
        this.user_type = 2;
    }
    public void setusertype() {
        int usertype= in.nextInt();
        this.user_type = usertype;
    }
    
    public int getusertype( int uid) {
        try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","Jj112233");  
           Statement stmt=con.createStatement(); 
           ResultSet rs=stmt.executeQuery("select  user_type from users Where User_id =\"" + uid + "\"");
           
         while(rs.next())
           {        
         
          this.user_type = rs.getInt(1);
           }
         con.close();
         //this.max = dbmax;
         //System.out.println(dbmax);
         
        }
        catch(Exception e)
              { 
                  System.out.println(e);
                  
              }  
        return this.user_type;
        
    }
    public int getlogin() {
        return loginstatus;
    }

    public void setlogin() {
        this.loginstatus = 1;
    }
    public void setlogout() {
        this.loginstatus = 0;
    }

   public boolean userValid()
    {
        String pass = null;
         ResultSet info =null;
        System.out.print("\nUsername: ");
        String username = in.next();
        System.out.print("\nPassword: ");
        String password = in.next();
        try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","Jj112233");  
           Statement stmt=con.createStatement(); 
           ResultSet rs=stmt.executeQuery("select  User_id, Username, Password, user_type from users Where Username =\"" + username + "\"");
           
         while(rs.next())
           {        
          this.User_id = rs.getInt(1);
          this.username= rs.getString(2);
          this.password= rs.getString(3);
          this.user_type = rs.getInt(4);
           }
         con.close();
         //this.max = dbmax;
         //System.out.println(dbmax);
         
        }
        catch(Exception e)
              { 
                  System.out.println(e);
                  
              }  
        
        if( password.equals(this.password))
        {
            System.out.print("\nEnter Successful\n");
            this.setlogin();
            return true;
        }
   
        else
        {
            System.out.println("\nInvalid username or password");
            return false;
        }
        
    }
   public int userValid(String uname, String Pass)
    {
        
         //ResultSet info =null;
          
        String un=null,pas=null;
            int uid=0, utype=0;
        
        try
       { 
           
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","Jj112233");  
           Statement stmt=con.createStatement(); 
           ResultSet rs=stmt.executeQuery("select  User_id, Username, Password, user_type from users Where Username =\"" + uname + "\"");
           while(rs.next())
           {        
           
          uid = rs.getInt(1);
          un= rs.getString(2);
          pas= rs.getString(3);
          utype = rs.getInt(4);
           }
           
         con.close();
         //this.max = dbmax;
         //System.out.println(dbmax);
         
          if( Pass.equals(pas))
        {
            JOptionPane.showMessageDialog(null, "Enter Successful");
            this.setlogin();
            
        }
   
        else
        {
            JOptionPane.showMessageDialog(null, "Invalid username or password", 
                                   "ERROR", JOptionPane.ERROR_MESSAGE);
            
            uid=0;
        }
          
       }
        catch(Exception e)
              { 
                  System.out.println(e);
                  uid=0;
                  
              } 
       return uid; 
    }
        
        
        
    
   
   public void ChangePassword(users so)
   {
       try
       { 
            String newPassword=null;
            if (this.userValid())
            {
                System.out.print("\nEnter the new Password: ");
                newPassword = in.next();
                Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection
                    ("jdbc:mysql://localhost:3306/podcast","root","Jj112233");  
                Statement stmt=con.createStatement(); 
         
          
                String insert_user = "UPDATE users SET  Password = \'" 
                    + newPassword + "\' WHERE Username = \'" + so.username +"\'";
           
                stmt.executeUpdate(insert_user);
                System.out.println("Password Changed  successfully ");
                con.close(); 
           }   
           else
           {
               System.out.println("You have not Permission to Change the Password");
           }
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
    }
   
   public void ChangePassword(int so, String pass2)
   {
       try
       { 
            String newPassword=null;
           
                
                Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection
                    ("jdbc:mysql://localhost:3306/podcast","root","Jj112233");  
                Statement stmt=con.createStatement(); 
         
          
                String insert_user = "UPDATE users SET  Password = \'" 
                    + pass2 + "\' WHERE User_id = \'" + so +"\'";
           
                stmt.executeUpdate(insert_user);
                JOptionPane.showMessageDialog(null, "Password Changed  successfully");
                
                con.close(); 
           
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
    }
   
   public void UpdateInfo(users so)
   {
      // System.out.print("\nEnter the full Name\n");
        //so.setadminname();
        System.out.print("\nEnter the Email\n");
        so.setEmail();
        System.out.print("\nEnter the Phone\n");
        so.setPhone();
       try
       { 
           
            if (this.userValid())
            {
                
                Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection
                    ("jdbc:mysql://localhost:3306/podcast","root","Jj112233");  
                Statement stmt=con.createStatement(); 
         
          
                String insert_user = "UPDATE users SET  phone = \'" 
                    + so.phone + "\', Email =\'" + so.email + "\'  WHERE Username = \'" + so.username +"\'";
           
                stmt.executeUpdate(insert_user);
                System.out.println("Password Changed  successfully ");
                con.close(); 
           }   
           else
           {
               System.out.println("You have not Permission to Change the Password");
           }
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
       
       
  
   }
   
   public void UpdateInfo(int  so, String email2, String phone, String name)
   {
      // System.out.print("\nEnter the full Name\n");
        //so.setadminname();
        int type = this.getusertype(so);
       try
       { 
           
            
                
                Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection
                    ("jdbc:mysql://localhost:3306/podcast","root","Jj112233");  
                Statement stmt=con.createStatement(); 
         
          
                String insert_user = "UPDATE users SET  phone = \'" 
                    + phone + "\', Email =\'" + email2 + "\'  WHERE User_id = " + so ;
           
                stmt.executeUpdate(insert_user);
                System.out.println("Password Changed  successfully ");
                if ( type == 1 )
                {
                  insert_user = "UPDATE admin SET  Admin_name = \'" 
                    + name +  "\'  WHERE Admin_id = " + so ;
           
                stmt.executeUpdate(insert_user);
                }
                else
                {
                  System.out.println("Password Changed  successfully ");
                }
                
                con.close(); 
              
           
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
       
       
  
   }
}
