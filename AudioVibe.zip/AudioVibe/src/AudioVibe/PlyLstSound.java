
package AudioVibe;

import java.util.Scanner;

public class PlyLstSound {
    public int plylst_id;
    public int sound_id;
    public String insert_date;
    public int isdeleted;//0--> not deleted    1--> deleted
    public int rate;
    public int user_id;
    
    static Scanner in = new Scanner(System.in);
    
    public int getrate() {
        return rate;
    }
    public void setrate() {
        System.out.print("\nType in the Podcast Rate: ");
        int n = in.nextInt();
        this.rate = n;
    }
    public void setdeleted() {
        this.isdeleted = 1;
    }
     public void setnotdeleted() {
        this.isdeleted = 0;
    }
     
     public String getinsert_date() {
        return insert_date;
    }
    public void setinsert_date() {
        System.out.print("\nType in the Podcast insert date: ");
        String n = in.next();
        this.insert_date = n;
    }
    
}
