
package AudioVibe;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class PlayList 
{
   public String PlayListName;
   public int PlayListID;
   public int isdeleted;
   public int cat_id;
   public int user_id;
   public String creation_date;
   static Scanner in = new Scanner(System.in);
   
   public void welcome()
    {
        System.out.println("\n\t\t This is your Play List ");
    }
  public  PlayList()
   {
       welcome();
   }
    public String getPlayListName() {
        return PlayListName;
    }

    public void setPlayListName() {
        System.out.print("\nEnter Play List Name : ");
        String pln=in.next();
        this.PlayListName = pln;
    }
    
    public int getPlayListID() {
        return PlayListID;
    }

    public void setPlayListID(int uid) {
        int plmax=1;
        try
       { 
           
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
           //String str="select nvl(max(PL_id)+1,1) from playlist Where user_id=" + uid;
           ResultSet rs=stmt.executeQuery("select max(PL_id) from playlist Where user_id=" + uid);
           //System.out.println(str);
           while(rs.next())
           { 
           plmax=rs.getInt(1) ; 
           }
           if (plmax==0)
           {
              this.PlayListID = 1; 
           }
           else
           {
             rs=stmt.executeQuery("select max(PL_id) from playlist Where user_id=" + uid);
           //System.out.println(str);
           while(rs.next())
           {
               this.PlayListID = rs.getInt(1) ;
           }  
           }
           con.close();
       }
        catch(Exception e)
              { 
                  System.out.println(e);
                 
              } 
         
        
         
    }
    
     public int getPlayListmax(int uid) {
        int plmax=1;
        try
       { 
           
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
           //String str="select nvl(max(PL_id)+1,1) from playlist Where user_id=" + uid;
           ResultSet rs=stmt.executeQuery("select count(PL_id) from playlist Where user_id=" + uid);
           //System.out.println(str);
           while(rs.next())
           { 
           plmax=rs.getInt(1) ; 
           }
           if (plmax==0)
           {
              plmax= 1; 
           }
           else
           {
             rs=stmt.executeQuery("select max(PL_id)+1 from playlist Where user_id=" + uid);
           //System.out.println(str);
           while(rs.next())
           {
               plmax=rs.getInt(1) ;
           }  
           }
           con.close();
       }
        catch(Exception e)
              { 
                  System.out.println(e);
                 
              } 
         
        return plmax;
         
    }
    
    public int getisdeleted() {
        return isdeleted;
    }

    public void setdeleted() {
        this.isdeleted = 1;
    }
     public void setnotdeleted() {
        this.isdeleted = 0;
    }
    
    public int getcatid() {
        return cat_id;
    }
    public void getCategories()
   {
       try
       { 
           
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
           ResultSet rs=stmt.executeQuery("select * from categories");
           
           while(rs.next())
           {
             System.out.println(rs.getInt(1) + "\t" + rs.getString(2)); 
                    
           }
           
         con.close();
         
         
        }
        catch(Exception e)
              { 
                  System.out.println(e);
                  
              }  
  
   }
    public void setcatid() {
        System.out.print("\nEnter the Category \t choose from the list: \n");
        getCategories();
        int cat=in.nextInt();
        this.cat_id = cat;
    }
    
    public String getCreationDate() {
        return creation_date;
    }

    public void setCreationDate() {
        System.out.print("\nEnter creation_date: ");
        String pln=in.next();
        this.creation_date = pln;
    }
    
    public int getuser_id() {
        return user_id;
    }

    public void setuser_id(int uid) {
        this.user_id = uid;
    }
    
    public void addtodbPL(PlayList Pl)
   {
       try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
          
           String insert_user = "insert into playlist (PL_id, PL_name, user_id, cat_id, creation_date, isdeleted) "
                   + "values(" + Pl.PlayListID + ",\"" +  Pl.PlayListName + "\"," +  Pl.user_id + "," 
                   + Pl.cat_id +",\"" + Pl.creation_date +"\","+ Pl.isdeleted + ")" ;
           System.out.println(insert_user);
           stmt.executeUpdate(insert_user);
           System.out.println("Data inserted successfully in Play List table");
           con.close();  
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
  
   }
    
    public void addtodbPL( String name, int isDelete, int cat, String cdate, int userid  )
   {
       int pl= this.getPlayListmax(userid);
       try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
          
           String insert_user = "insert into playlist (PL_id, PL_name, user_id, cat_id, creation_date, isdeleted) values(" 
                   + pl + ",\'" +  name + "\'," +  userid + "," + cat +",\'" + cdate +"\',"+ isDelete + ")" ;
           
           JOptionPane.showMessageDialog(null, insert_user);
           stmt.executeUpdate(insert_user);
           JOptionPane.showMessageDialog(null, "Data inserted successfully in Play List table");
           con.close();  
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
  
   }
    
     public void updatedbPL(PlayList Pl)
   {
       try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
          
           String insert_user = "UPDATE playlist SET  PL_name = \'" + Pl.PlayListName + "\', cat_id = " 
                   + Pl.cat_id + " WHERE user_id = " + Pl.user_id ;
           System.out.println(insert_user);
           stmt.executeUpdate(insert_user);
           System.out.println("Informations Updated successfully in Play List table");
           con.close();  
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
   }
     public void DeletedbPL(int uid, int plid)
   {
       try
       { 
           DisplayPlayListSound(uid, plid);
           int st = JOptionPane.showConfirmDialog(null, "Do you want to continue?", "Confirmation", JOptionPane.YES_NO_OPTION);
           if (st == JOptionPane.YES_OPTION) 
           {
               MakeitEmpty( uid,  plid);
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
            
           String insert_user = "DELETE FROM playlist WHERE user_id=" 
                   + uid + " AND PL_id=" + plid ;
           System.out.println(insert_user);
           stmt.executeUpdate(insert_user);
           System.out.println("Informations Updated successfully in Play List table");
           con.close();
           }
           
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }
        
   }
     
      public void MakeitEmpty(int uid, int plid)
   {
       try
       { 
           
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
          
           String insert_user = "DELETE FROM playlist_sound WHERE user_id=" 
                   + uid + " AND PL_id=" + plid ;
           System.out.println(insert_user);
           stmt.executeUpdate(insert_user);
           System.out.println("Informations Updated successfully in Play List table");
           con.close();
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }
        
   }
      
      public void DeleteSoundfromPL(int uid, int plid,int sid)
   {
       try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
          
           String insert_user = "DELETE FROM playlist_sound WHERE user_id=" 
                   + uid + " AND PL_id=" + plid + " AND sound_id =" + sid ;
           System.out.println(insert_user);
           stmt.executeUpdate(insert_user);
           System.out.println("Informations Updated successfully in Play List table");
           con.close();
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }
        
   }
     public void DisplayPlayListSound(int uid, int plid)
   {
       try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
           ResultSet rs=stmt.executeQuery("select sound_id,insert_date, isdeleted, Rate from playlist_sound where user_id=" 
                   + uid + " AND PL_id=" + plid );
           System.out.println("sound_id\tinsert_date\t isdeleted\t Rate");
           System.out.println("----------------------------------------------");
           while(rs.next())
           {
             System.out.println(rs.getInt(1) + "\t" + rs.getString(2)
             + "\t" + rs.getInt(3)+ "\t" + rs.getInt(4)); 
           }
         con.close();
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
   }
   
     public void DisplayPlayList(int uid)
   {
       try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
           ResultSet rs=stmt.executeQuery("select PL_id, PL_name, user_id, cat_id, isdeleted,creation_date  from playlist where user_id=" + uid);
           System.out.println("PlayList id\tPlaylist name\tUser_id\tCategory\tdeleted\tinsert_date");
           System.out.println("---------------------------------------------------------------------");
           while(rs.next())
           {
             System.out.println(rs.getInt(1) + "\t" + rs.getString(2)
             + "\t" + rs.getInt(3)+ "\t" + rs.getInt(4)+ "\t" + rs.getString(5)); 
           }
         con.close();
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
   }
     public void AddtoPlylst(int uid, int plid)
     {
         Sounds sound = new Sounds();
         PlyLstSound pl_sound = new PlyLstSound();
         sound.viewPodcast();
         System.out.println("Select the Sound you want to Add");
         pl_sound.sound_id =in.nextInt();
         pl_sound.setnotdeleted();
         pl_sound.getrate();
         pl_sound.getinsert_date();
         pl_sound.user_id=uid;
         pl_sound.plylst_id=plid;
         try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
          
           String insert_user = "insert into playlist_sound (PL_id, sound_id, user_id, insert_date, Rate, isdeleted) "
                   + "values(" + pl_sound.plylst_id + "," +  pl_sound.sound_id + "," +  pl_sound.user_id + ",\"" 
                   + pl_sound.insert_date +"\"," + pl_sound.rate +","+ pl_sound.isdeleted + ")" ;
           System.out.println(insert_user);
           stmt.executeUpdate(insert_user);
           System.out.println("Data inserted successfully in Play List table");
           con.close();  
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
  
         
     }
}
