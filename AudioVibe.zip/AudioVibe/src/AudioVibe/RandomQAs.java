//اذا كان المستخدم جديد تظهر له مجموعة اسئلة يجاوب عنها عشان نعرف اهتماماته
package AudioVibe;
//package podcastaudiovibe;

import java.util.Scanner;

public class RandomQAs{
    public void welcome()
    {
        System.out.println("\n\t\tWelcome, valued listener! Your insights matter."
                + "\n\t\tAs we embark on a quest for continuous improvement, "
                + "\n\t\twe invite you to share your thoughts in this brief survey. "
                + "\n\t\tYour feedback will shape the future of our podcast, "
                + "\n\t\tensuring it resonates with you on every level. "
                + "\n\t\tLet's make this journey even more extraordinary together!");
    }
    
    Scanner in = new Scanner(System.in);

    public int episodeNo;
    public int podcastProgramNo;
    public String chooseInterest;
    public String listenORwatch;
    public String nonArabic;
    public int user_id;

    public RandomQAs()
            {
                welcome();
            }

  
    public int getUser() {
        return user_id;
    }

    public void setUser(int userid) {
        this.user_id = userid;
    }

    public int getEpisodeNo() {
        return episodeNo;
    }

    public void setEpisodeNo() {
        System.out.print("\nHow many podcast episodes have you watched during the last 30days: ");
        this.episodeNo =  in.nextInt();
    }

    public int getPodcastProgramNo() {
        return podcastProgramNo;
    }

    public void setPodcastProgramNo() {
        System.out.print("\nHow many podcast program have you watched: ");
        this.podcastProgramNo = in.nextInt();
    }

    public String getChooseInterest() {
        return chooseInterest;
    }

    public void setChooseInterest() {
        ChooseIntersts();
    }

    public String getListenORwatch() {
        return listenORwatch;
    }

    public void setListenORwatch() {
        System.out.print("\nWould you rather listen or watch the episodes: ");
        this.listenORwatch = in.next();
    }

    public String getNonArabic() {
        return nonArabic;
    }

    public void setNonArabic() {
        System.out.print("\nDo you listen to non Arabic podcasts: ");
        this.nonArabic = in.next();
    }
    
   
    
    public void ChooseIntersts()
    {
        in.nextLine();
        System.out.print("\nChoose your interests: "
                + "\n\tStories"
                + "\n\tCrime"
                + "\n\tFashion"
                + "\n\tEconomy"
                + "\n\tFood"
                + "\n\tRelationships"
                + "\n\tLangueges"
                + "\n\tMental-Health"
                + "\n\tLaw"
                + "\n\tTravel"
                + "\n\tComedy"
                + "\n\tScience"
                + "\n\tSport"
                + "\n\tTechnology"
                + "\n\tHistory"
                + "\n\tSelfDevelopment"
                + "\n\tMarkting"
                + "\n\tEducation"
                + "\n\tBooks"
                + "\n\tBiography"
                + "\n\t-->");
        chooseInterest = in.nextLine();
        System.out.println();
    }
    
    
   
}
