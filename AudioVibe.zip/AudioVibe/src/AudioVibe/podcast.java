package AudioVibe;

import java.sql.SQLException;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import java.sql.Statement;

public class podcast {
    
    static Scanner in = new Scanner(System.in); 
        
    
    


    public static void main(String[] args) throws ClassNotFoundException, SQLException 
    {
       /* System.out.println("\n**********************************************");
        System.out.println("\tWelcome in Podcast Application \n\t\tAre you new?"
                + "\n-------------------------------------------------------"
                + "\n\t======> Press 1 to register <====== "
         + "\n-------------------------------------------------------");
        System.out.println("**********************************************\n");
        users user = new users();
        int n = in.nextInt();
        if (n==1)
            user.adduser();
        if(user.userValid())
        {
            admin Admin = new admin();
            if (user.user_type==1)
            {
                
                System.out.println("******************************");
                System.out.println("       You are Admin ");
                System.out.println("******************************\n");
                Admin.adminMenu();
            }
            else
            {
                End_user User = new End_user();
               System.out.println("******************************");
               System.out.println("       You are User"); 
               System.out.println("******************************\n");
               User.userMenu(user);
            }
        
        }*/
        StartPage stpage = new StartPage();
           stpage.setVisible(true);
    }
    
}
