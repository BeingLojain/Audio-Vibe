
package AudioVibe;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class admin extends users
{
   public String admin_name;
    static Scanner in = new Scanner(System.in); 
    
    public String getadminname() {
        return admin_name;
    }

    public void setadminname() {
        String adminname=in.next();
        this.admin_name = adminname;
    }
    public void adminMenu() throws ClassNotFoundException, SQLException
    {
        int ch,t;
        Categories cat = new Categories();
        Nationality nat = new Nationality();
        do
          {
              System.out.print("\n 1 Content Management"
                       + "\n 2 Change Password"
                       + "\n 3 Update Information"
                       + "\n 4 Add Category "
                       + "\n 5 Update Category "
                       + "\n 6 View Category "
                       + "\n 7 Add Nationality"
                       + "\n 8 Update Nationality"
                       + "\n 9 View Nationality "
                       + "\n 10 Add New Admin "
                       + "\n 11 Add New User "
                    + "\n12_Back"
                    + "\n-->");
         ch = in.nextInt();
            switch(ch)
                {
                    case 1:
                        contentManagement();
                        break;
                    case 2:
                        ChangePassword(this);
                        break;
                    case 3:
                        UpdateInfo(this);
                        break;
                    case 4:
                        cat.viewdbCategories();
                        System.out.println("\n\t\t1 to add New Category  \n\t\tPress Other to Exit adding ");
                        t = in.nextInt();
                        while(t==1)
                        {
                            cat.setcatname();
                            cat.addCattoDB();
                            cat.viewdbCategories();
                            System.out.println("\n\t\t1 to add New Category  \n\t\tPress Other to Exit adding ");
                            t = in.nextInt();
                        }
                        break;
                    case 5:
                        cat.viewdbCategories();
                        System.out.println("\n\t\t1 Enter the Id of Category to update");
                        int cid = in.nextInt();
                        System.out.println("\n\t\t1 Enter new Description of Category to update");
                        String cdesc =in.next();
                        cat.UpdateCattoDB(cid, cdesc);
                        break; 
                    case 6:
                        cat.viewdbCategories();
                        break;
                    case 7:
                        nat.viewdbNationality();
                        System.out.println("\n\t\t1 to add New Nationality  \n\t\tPress Other to Exit adding ");
                        t = in.nextInt();
                        while(t==1)
                        {
                            nat.setnatname();
                            nat.addNattoDB();
                            nat.viewdbNationality();
                            System.out.println("\n\t\t1 to add New Nationality  \n\t\tPress Other to Exit adding ");
                            t = in.nextInt();
                        }
                        break;   
                    case 8:
                        nat.viewdbNationality();
                        System.out.println("\n\t\t1 Enter the Id of Nationality to update");
                        int nid = in.nextInt();
                        System.out.println("\n\t\t1 Enter new Description of Nationality to update");
                        String ndesc =in.next();
                        nat.UpdateNattoDB(nid, ndesc);
                        break;
                    case 9:
                        nat.viewdbNationality();
                        break;
                    case 10:
                        super.addadmin();
                        break;
                    case 11:
                        super.adduser();
                        break;    
                    default:
                        System.out.println("Invalid");
                } 
          }while(ch!=12);
    }
    // @Override UpdateInfo
    public void UpdateInfo(admin so)
   {
        System.out.print("\nEnter the full Name\n");
        so.setadminname();
        System.out.print("\nEnter the Email\n");
        so.setEmail();
        System.out.print("\nEnter the Phone\n");
        so.setPhone();
       try
       { 
           
            if (this.userValid())
            {
                
                Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection
                    ("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
                Statement stmt=con.createStatement(); 
         
          
                String insert_user = "UPDATE users SET  phone = \'" 
                    + so.phone + "\', Email =\'" + so.email + "\'   WHERE Username = \'" + so.username +"\'";
           
                stmt.executeUpdate(insert_user);
                
                insert_user = "UPDATE admin SET  Admin_name = \'" 
                    + so.admin_name + "\'   WHERE Admin_id = \'" + so.User_id +"\'";
           
                stmt.executeUpdate(insert_user);
                
                System.out.println("Password Changed  successfully ");
                con.close(); 
           }   
           else
           {
               System.out.println("You have not Permission to Change the Password");
           }
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
       
       
  
   }
    
    public static void contentManagement()
    {
        Sounds Epso = new Sounds();
        int ch;
            do
            {
                System.out.print("\n1_Add Contenet"
                + "\n2_Delete Contenet"
                + "\n3_Update Contenet"
                + "\n4_Dispaly all Contenet"
                + "\n5_Back"
                + "\n-->");
             ch = in.nextInt();
                switch(ch)
                {
                    case 1:
                        addpodcast();
                        break;
                    case 2:
                        deletepodcast();
                        break;
                    case 3:
                        updatepodcast();
                        break;
                    case 4:
                        displaypodcast();
                        break;
                    default:
                        System.out.println("Invalid");
                }
            }while(ch!=5);
    }
   public static void addpodcast()
    {
        Sounds Epso = new Sounds();
        System.out.print("\n Add Podcast ");
        Epso.setPodcastType();
        Epso.setUrl_id();
        Epso.setrate();
        Epso.setalbumName();
        Epso.setsinger();
        Epso.setPodcastName();
        Epso.setsound_id(Epso.getsoundmax());
        Epso.setHoster();
        Epso.setPodcastEpisodes();
        Epso.setepisodeTitle();
        Epso.setpublishdate();
        Epso.addtodbSound();
    }
   
   public static void addpodcast(int rate, int ptype, int podE, String album, String url,String singer, String podname, String hoster , String ept, String publish)
    {
        Sounds Epso = new Sounds();
        Epso.setsound_id(Epso.getsoundmax());
        Epso.Hoster = hoster;
        Epso.PodcastEpisodes = podE;
        Epso.PodcastName = podname;
        Epso.PodcastType = ptype;
        Epso.Url_id = url;
        Epso.albumName = album;
        Epso.episodeTitle = ept;
        Epso.publishdate = publish;
        Epso.rate = rate;
        Epso.singer = singer;
        Epso.addtodbSound();
    }
   public static void deletepodcast()
    {
        Sounds sound = new Sounds();
        System.out.print("\n Delete Podcast ");
        sound.viewPodcast();
        System.out.print("\n Enter Sound ID to deleted: ");
        int sid = in.nextInt();
        sound.deleteSound(sid);
    }
   public static void updatepodcast()
    {
        Sounds Epso = new Sounds();
        System.out.print("\n Update Podcast ");
        Epso.viewPodcast();
        System.out.print("\n Enter Sound ID to Updated: ");
        int sid = in.nextInt();
        Epso.setPodcastType();
        Epso.setUrl_id();
        Epso.setrate();
        Epso.setalbumName();
        Epso.setsinger();
        Epso.setPodcastName();
        Epso.setsound_id(sid);
        Epso.setHoster();
        Epso.setPodcastEpisodes();
        Epso.setepisodeTitle();
        Epso.setpublishdate();
        Epso.UpdateSound( Epso );
        
    }
   public static void displaypodcast()
    {
        System.out.print("\n display all Podcasts ");
        Sounds sound = new Sounds();
        sound.viewPodcast();
        
    }
                   
            
        
    
    
}
