
package AudioVibe;
   
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.*;  
import java.util.Scanner;


public class Nationality {
    
    public String nat_name;
    public int nat_id;
    static Scanner in = new Scanner(System.in);
    
       public void welcome()
    {
        System.out.println("\n\t\tNow we are in Nationality Class \n");
        //System.out.println("\n\t\tPress 1 to add New Category  \n\t\tPress other to Exit adding ");
    }
    
     public  Nationality ( ) throws ClassNotFoundException, SQLException
    {
             welcome();
    }
   
     public String getnatname()
     {
         return this.nat_name ;
     }
     public int getnatid()
     {
         return this.nat_id ;
     }
     public void setnatname()
     {
         System.out.print("\nEnter New Nationality Description: ");
         String nat = in.next();
          this.nat_name = nat;
     }
     public void setnatid()
     {
         System.out.print("\nEnter New Nationality ID: ");
         int nat = in.nextInt();
          this.nat_id = nat;
     }
     
     public void viewdbNationality()
   {
       try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
           ResultSet rs=stmt.executeQuery("select * from nationality");
           System.out.println("Nationality ID \t\tNationality Description");
           System.out.println("------------\t\t--------------------");
         while(rs.next())  
          System.out.println(rs.getInt(1)+"\t\t"+rs.getString(2));  
         con.close();  
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
  
   }
     
    public void addNattoDB () throws ClassNotFoundException, SQLException
     {
       try
       {
           int nat=this.getmaxNat();
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
           String insert_user = "insert into nationality (nat_id, nat_name) values(" + nat + "," + this.nat_name + ")";
           
           stmt.executeUpdate(insert_user);
           System.out.println("Data inserted successfully in Nationality table");
           con.close();  
       }
       catch(SQLException e)
       {
           e.printStackTrace();
       }
     }
    public void addNattoDB ( String natdesc) throws ClassNotFoundException, SQLException
     {
       try
       {
           int nat=this.getmaxNat();
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
           String insert_user = "insert into nationality (nat_id, nat_name) values(" + nat + ",\'" + natdesc + "\')";
           
           stmt.executeUpdate(insert_user);
           System.out.println("Data inserted successfully in Nationality table");
           con.close();  
       }
       catch(SQLException e)
       {
           e.printStackTrace();
       }
     }
    public void UpdateNattoDB (int natid, String natdesc) throws ClassNotFoundException, SQLException
     {
       try
       {
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
           String insert_user = "update nationality set nat_name=\'" + natdesc + "\'where nat_id=" + natid ;
           
           stmt.executeUpdate(insert_user);
           System.out.println("Data Updated Successfully in Nationality Table");
           con.close();  
       }
       catch(SQLException e)
       {
           e.printStackTrace();
       }
     }
    
     public int getmaxNat()
   {
       try
       { 
           int dbmax = 0;
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
           ResultSet rs=stmt.executeQuery("select MAX(nat_id)+1 from nationality");
           
           while(rs.next())
           {
            // System.out.println(rs.getInt(1)); 
           dbmax=rs.getInt(1);
          
           }
           
         con.close();
         //this.max = dbmax;
         //System.out.println(dbmax);
         return dbmax;
        }
        catch(Exception e)
              { 
                  System.out.println(e);
                  return 0;
              }  
  
   }
   
    
    
}
