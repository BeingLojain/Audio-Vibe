
package AudioVibe;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Sounds 
{
    public String PodcastName;
    public String albumName;
    public String publishdate;
    public int PodcastEpisodes;
    public String Hoster;
    public String singer;
    public int PodcastType;
    public String episodeTitle;
    public String Url_id;
    public int rate;
    public int sound_id;
    static Scanner in = new Scanner(System.in);
    
    public void addtodbSound()
   {
       try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
          
          sound_id = getsoundmax();
           String insert_user = "insert into sound "
                   + "(PodcastName, albumName,publishdate, "
                   + "PodcastEpisodes, Hoster, singer, PodcastType,"
                   + " episodeTitle, Url_id, rate, sound_id )"
                   + " values(\"" + PodcastName + "\",\"" +  albumName 
                   + "\",\"" + publishdate + "\"," +  PodcastEpisodes 
                   +  ",\"" + Hoster  +  "\",\"" +  singer  +  "\"," +
                   PodcastType + ",\"" + episodeTitle + "\",\"" + Url_id + 
                   "\"," + rate + "," + sound_id + ")" ;
           
           stmt.executeUpdate(insert_user);
           System.out.println("Data inserted successfully in Sound table");
           con.close();  
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
  
   }
    
    public void UpdateSound(Sounds so)
   {
       try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
          
          
           String insert_user = "UPDATE sound SET  PodcastName = \'" + so.PodcastName +
                   "\', albumName = \'" +so.albumName + "\', publishdate =\'" +so.publishdate +
                   "\' , PodcastEpisodes="+ so.PodcastEpisodes + " , Hoster = \'" +
                   so.Hoster+ "\', singer =\'" + so.singer + "\', PodcastType=" + so.PodcastType + 
                   ", episodeTitle=\'" + so.episodeTitle + "\', Url_id =\'" +so.Url_id +"\', rate = " 
                   + so.rate + " WHERE sound_id=" + so.sound_id;
           
           stmt.executeUpdate(insert_user);
           System.out.println("Data Updated successfully on Sound table");
           con.close();  
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
  
   }
    
      public void deleteSound(int sid)
   {
       try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
          
          sound_id = getsoundmax();
           String insert_user = "delete from sound where sound_id="+ sid ;
           
           stmt.executeUpdate(insert_user);
           System.out.println("Data Deleted successfully from Sound table");
           con.close();  
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
  
   }
      
        
    public String getPodcastName() {
        return PodcastName;
    }
    public void setPodcastName() {
        System.out.print("\nType in the Podcast Name: ");
        String st = in.next();
        this.PodcastName = st;
    }
    
    public String getalbumName() {
        return albumName;
    }
    public void setalbumName() {
        System.out.print("\nType in the Podcast Album Name: ");
        String st = in.next();
        this.albumName = st;
    }
    
    public String getpublishdate() {
        return publishdate;
    }
    public void setpublishdate(){
        System.out.println("\nType the Podcast Publish Date: ");
        String st = in.next();
        this.publishdate = st;
    }
    
    public int getPodcastEpisodes() {
        return PodcastEpisodes;
    }
    public void setPodcastEpisodes() {
        System.out.print("\nType in the Podcast's Episodes Number: ");
        int n = in.nextInt();
        this.PodcastEpisodes = n;
    }
    
    public String getHoster() {
        return Hoster;
    }
    public void setHoster() {
        System.out.print("\nType in the Podcast Hoster: ");
        String st = in.next();
        this.Hoster = st;
    }
    
    public String getsinger() {
        return singer;
    }
    public void setsinger() {
        System.out.print("\nType in the Podcast Singer: ");
        String st = in.next();
        this.singer = st;
    }
    
    public int getPodcastType() {
        return PodcastType;
    }
    public void setPodcastType() {
        System.out.print("\nType in the Podcast Category Type: \n choose one of these\n");
        this.getCategories();
        int n = in.nextInt();
        this.PodcastType = n;
    }
    
    public String getepisodeTitle() {
        return episodeTitle;
    }
    public void setepisodeTitle() {
        System.out.println("\nType in Episode Title and Duration: ");
        String st = in.next();
        this.episodeTitle = st;
    }
    
    public String getUrl_id() {
        return Url_id;
    }
    public void setUrl_id() {
        System.out.print("\nType in the Podcast URL: ");
        String st = in.next();
        this.Url_id = st;
    }
    
    public int getrate() {
        return rate;
    }
    public void setrate() {
        System.out.print("\nType in the Podcast Rate: ");
        int n = in.nextInt();
        this.rate = n;
    }
    
    public int getsound_id() {
        return sound_id;
    }
    public void setsound_id(int sound_Id) {
        this.sound_id = sound_Id;
    }
    
   public int getsoundmax()
   {
       try
       { 
           int dbmax = 0;
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
           ResultSet rs=stmt.executeQuery("select MAX(sound_id)+1 from sound");
           
           while(rs.next())
           {
             
           dbmax=rs.getInt(1);
          
           }
           
         con.close();
         
         return dbmax;
        }
        catch(Exception e)
              { 
                  System.out.println(e);
                  return 0;
              }  
  
   }
   
   public void viewPodcast()
   {
       try
       { 
           
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
           ResultSet rs=stmt.executeQuery("select * from sound");
           
           while(rs.next())
           {
            
           System.out.println(rs.getInt(1) + "\t" + rs.getString(2)
           + "\t" + rs.getInt(3)+ "\t" + rs.getString(4)+ "\t" + rs.getString(5)
           + "\t" + rs.getString(6)+ "\t" + rs.getInt(7)+ "\t" + rs.getString(8)
           + "\t" + rs.getString(9)+ "\t" + rs.getString(10)+ "\t" + rs.getString(11));
          
           }
           
         con.close();
         
         
        }
        catch(Exception e)
              { 
                  System.out.println(e);
                  
              }  
  
   }
   
   public void getCategories()
   {
       try
       { 
           
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
           ResultSet rs=stmt.executeQuery("select * from categories");
           
           while(rs.next())
           {
             System.out.println(rs.getInt(1) + "\t" + rs.getString(2)); 
                    
           }
           
         con.close();
         
         
        }
        catch(Exception e)
              { 
                  System.out.println(e);
                  
              }  
  
   }
    
}
