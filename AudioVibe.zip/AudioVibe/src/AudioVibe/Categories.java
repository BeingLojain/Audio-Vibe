//انواع البودكاستات
package AudioVibe;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.*;  
import java.util.Scanner;

public final class Categories 
{
    
    public String Cat_Name;
    public int Cat_ID;
    static Scanner in = new Scanner(System.in);
    
    public void welcome()
    {
        System.out.println("\n\t\tNow we are in Category Class \n");
        //System.out.println("\n\t\tPress 1 to add New Category  \n\t\tPress other to Exit adding ");
    }
    
    
     public  Categories () throws ClassNotFoundException, SQLException
    {
       welcome();
       
       
       
    }
     public String getcatname()
     {
         return this.Cat_Name ;
     }
     public int getcatid()
     {
         return this.Cat_ID ;
     }
     public void setcatname()
     {
         System.out.print("\nEnter New Category Description: ");
         String cat = in.next();
          this.Cat_Name = cat;
     }
     public void setcatid()
     {
         System.out.print("\nEnter New Category ID: ");
         int cat = in.nextInt();
          this.Cat_ID = cat;
     }
     
     public void viewdbCategories()
   {
       try
       { 
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
           ResultSet rs=stmt.executeQuery("select * from categories");
           System.out.println("Category ID \t\tCategory Description");
           System.out.println("------------\t\t--------------------");
         while(rs.next())  
          System.out.println(rs.getInt(1)+"\t\t"+rs.getString(2));  
         con.close();  
        }
        catch(Exception e)
              { 
                  System.out.println(e);
              }  
  
   }
     
    public void addCattoDB () throws ClassNotFoundException, SQLException
     {
       try
       {
           int catid= this.getmaxCat();
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
           
           String insert_user = "insert into categories (cat_id, cat_name) values(" + catid + "," + this.Cat_Name + ")";
           
           stmt.executeUpdate(insert_user);
           System.out.println("Data inserted successfully in Categories table");
           con.close();  
       }
       catch(SQLException e)
       {
           e.printStackTrace();
       }
     }
    
    public void addCattoDB (String catname) throws ClassNotFoundException, SQLException
     {
       try
       {
           int catid= this.getmaxCat();
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
           
           String insert_user = "insert into categories (cat_id, cat_name) values(" + catid + ",\'" + catname + "\')";
           
           stmt.executeUpdate(insert_user);
           System.out.println("Data inserted successfully in Categories table");
           con.close();  
       }
       catch(SQLException e)
       {
           e.printStackTrace();
       }
     }
    public void UpdateCattoDB (int catid, String catdesc) throws ClassNotFoundException, SQLException
     {
       try
       {
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
           String insert_user = "update categories set cat_name=\'" + catdesc + "\'where cat_id=" + catid ;
           
           stmt.executeUpdate(insert_user);
           System.out.println("Data Updated successfully in Categories table");
           con.close();  
       }
       catch(SQLException e)
       {
           e.printStackTrace();
       }
     }
    
     public int getmaxCat()
   {
       try
       { 
           int dbmax = 0;
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/podcast","root","CasRoot@20");  
           Statement stmt=con.createStatement(); 
           ResultSet rs=stmt.executeQuery("select MAX(cat_id)+1 from categories");
           
           while(rs.next())
           {
            // System.out.println(rs.getInt(1)); 
           dbmax=rs.getInt(1);
          
           }
           
         con.close();
         //this.max = dbmax;
         //System.out.println(dbmax);
         return dbmax;
        }
        catch(Exception e)
              { 
                  System.out.println(e);
                  return 0;
              }  
  
   }
     
//    System.out.print("\nChoose your interests: "
//                + "\nStories"
//                + "\nCrime"
//                + "\nFashion"
//                + "\nEconomy"
//                + "\nFood"
//                + "\nRelationships"
//                + "\nLangueges"
//                + "\nMental-Health"
//                + "\nLaw"
//                + "\nTravel"
//                + "\nComedy"
//                + "\nScience"
//                + "\nSport"
//                + "\nTechnology"
//                + "\nHistory"
//                + "\nSelfDevelopment"
//                + "\nMarkting"
//                + "\nEducation"
//                + "\nBooks"
//                + "\nBiography");
    
}
