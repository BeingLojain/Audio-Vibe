
package AudioVibe;

import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;


public class User_type {
    static final String Con_str = "jdbc:mysql://localhost:3306/podcast?zeroDateTimeBehavior=CONVERT_TO_NULL";
    
    public String type_desc;
    public int type_id;
    
     public  User_type ( String typedesc, int typeid) throws ClassNotFoundException, SQLException
    {
        this.type_desc = typedesc;
        this.type_id = typeid;
        addtype(typedesc, typeid);
    }
     
      public void  gettype ( )
    {
       System.out.println(this.type_desc + "\t" + this.type_id );
        
    }
      
      public void addtype (String typedesc, int typeid) throws ClassNotFoundException, SQLException
     {
       try
       {
          // Class.forName("com.mysql.jdbc.Driver");
           Connection conn = DriverManager.getConnection(Con_str, "root", "CasRoot@20");
           Statement st = conn.createStatement();
           String sql_db ="Create database if not exists podcast";
           st.executeLargeUpdate(sql_db);
           String use_dba = "use podcast";
           st.executeLargeUpdate(use_dba);
           String sql_table = "Create table if not exists user_type (type_id int, type_desc varchar(100))";
           st.executeLargeUpdate(sql_table);
           String sql_insert = " insert into user_type vlues(" + typeid + "," + typedesc + ")";
           st.executeLargeUpdate(sql_insert);
           System.out.println("Data inserted successfully in user_type table");
           conn.close();
        }
       catch(SQLException e)
       {
           e.printStackTrace();
       }
     }
    
}
